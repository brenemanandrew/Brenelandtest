// world-refresh test: converted Meshy models for the props that are swapped (see world-refresh/tools/make_testgame.py).
// ?oldworld (or ?oldtrees) turns every swap off; a model that fails to load leaves the old code-made prop in place.
import * as THREE from 'three';
import { GLTFLoader } from '../vendor/three/jsm/loaders/GLTFLoader.js';
const _c = new THREE.Color();
export const RM = {};
export const MUTE = { add() { return this; }, boxMinMax() { return this; } };
const q = new URLSearchParams(location.search);
if (!q.has('oldworld') && !q.has('oldtrees')) {
  const ld = new GLTFLoader();
  await Promise.all(["flower_patch", "hedge_bush", "topiary_ball", "raised_bed", "lettuce", "carrots", "strawberries", "tomatoes", "pumpkins", "sunflower", "hedge_box", "shore_rock", "scarecrow", "water_butt", "watering_can", "wheelbarrow", "mailbox", "picket_fence", "potting_shed", "fence_picket_0", "fence_picket_1", "fence_picket_2", "fence_post", "fence_rail"].map(async k => {
    try { const gl = await ld.loadAsync('/models/refresh/' + k + '.glb'); let m = null; gl.scene.traverse(o => { if (o.isMesh && !m) m = o; });
      const g = m.geometry.index ? m.geometry.toNonIndexed() : m.geometry.clone(), c = g.attributes.color;
      if (c && c.itemSize === 4) { const a = new Float32Array(c.count * 3); for (let i = 0; i < c.count; i++) { _c.setRGB(c.getX(i), c.getY(i), c.getZ(i), THREE.SRGBColorSpace); a[i * 3] = _c.r; a[i * 3 + 1] = _c.g; a[i * 3 + 2] = _c.b; } g.setAttribute('color', new THREE.BufferAttribute(a, 3)); }
      RM[k] = g;
    } catch (e) { console.warn('refresh model failed, keeping the code prop', k, e); }
  }));
}
export const RT = {};   // textured models (their own mesh, the painted texture kept)
if (!q.has('oldworld') && !q.has('oldtrees')) {
  const ld = new GLTFLoader(), { GRADIENT_3 } = await import('./toon.js');
  await Promise.all(["flower_patch", "hedge_bush", "topiary_ball", "fern", "mossy_rock", "log", "mushrooms", "potting_shed", "raised_bed", "lettuce", "carrots", "strawberries", "tomatoes", "pumpkins", "sunflower", "hedge_box", "shore_rock", "scarecrow", "water_butt", "watering_can", "wheelbarrow", "mailbox", "picket_fence"].map(async k => { try { const gl = await ld.loadAsync('/models/refresh/tex/' + k + '.glb'); let m = null; gl.scene.traverse(o => { if (o.isMesh && !m) m = o; });
    RT[k] = new THREE.MeshToonMaterial({ map: m.material.map, gradientMap: GRADIENT_3, side: ['hedge_box', 'fern', 'sunflower', 'tomatoes', 'carrots', 'strawberries', 'lettuce', 'pumpkins'].includes(k) ? THREE.DoubleSide : THREE.FrontSide }); /* (leafy models: thin leaves have a back too) */ RT[k].userData.geo = m.geometry; RM[k] = RM[k] || m.geometry; } catch (e) { console.warn('refresh textured model failed', k, e); } }));
}
export const RP = {};   // props.json shapes, textured (props-static.js draws them instanced)
if (!q.has('oldworld') && !q.has('oldtrees')) {
  const ld = new GLTFLoader(), { GRADIENT_3 } = await import('./toon.js');
  await Promise.all(["street_lamp", "post_lantern", "camp_lantern", "planter_brick", "bench_park", "picnic_table", "picnic_table_long", "shelter"].map(async k => { try { const gl = await ld.loadAsync('/models/refresh/tex/prop_' + k + '.glb'); let m = null; gl.scene.traverse(o => { if (o.isMesh && !m) m = o; });
    RP[k] = { geo: m.geometry, mat: new THREE.MeshToonMaterial({ map: m.material.map, gradientMap: GRADIENT_3 }) }; } catch (e) { console.warn('refresh prop failed, keeping the colour version', k, e); } }));
}
const _rm = new THREE.Matrix4(), _rq = new THREE.Quaternion(), _rp = new THREE.Vector3(), _rs = new THREE.Vector3(), _ry = new THREE.Vector3(0, 1, 0);
export function rmesh(parent, k, x, y, z, { s = 1, ry = 0 } = {}) {
  if (!RT[k]) return null; const m = new THREE.Mesh(RT[k].userData.geo, RT[k]); m.position.set(x, y, z); m.rotation.y = ry; m.scale.setScalar(s);
  m.castShadow = m.receiveShadow = true; m.userData.noMerge = true; parent.add(m); return m;
}
// add a model to a batcher: x, y = ground under its centre, z; s or sx/sy/sz scale; ry yaw
export function rput(b, k, x, y, z, { s = 1, sx, sy, sz, ry = 0 } = {}) {
  if (RT[k] && b.addInst) { _rm.compose(_rp.set(x, y, z), _rq.setFromAxisAngle(_ry, ry), _rs.set(sx ?? s, sy ?? s, sz ?? s)); b.addInst(k, RT[k].userData.geo, RT[k], _rm); return; }
  if (RM[k]) b.add(RM[k], '#ffffff', { x, y, z, ry, sx: sx ?? s, sy: sy ?? s, sz: sz ?? s });
}
